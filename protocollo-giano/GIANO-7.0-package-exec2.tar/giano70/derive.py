#!/usr/bin/env python3
"""GIANO-7.0 — derivazione normativa di (I_j, D_j).

Indici I_j sono 1-based in {1,...,32}.
"""
from __future__ import annotations

import hashlib
from typing import Iterable, List, Sequence, Tuple

DOMAIN_MC = b"GIANO-7.0-MC"
SEP = b"\x00"

def _forbid_id(s: str, name: str) -> None:
    if not s or not s.isascii():
        raise ValueError(f"{name} deve essere ASCII non vuoto")
    for ch in "|\r\n\x00":
        if ch in s:
            raise ValueError(f"{name} contiene carattere vietato")


def message(rhex: str, id_protocollo: str, id_lab: str, id_lotto: str, j: int) -> str:
    if j < 1:
        raise ValueError("j deve essere >= 1")
    _forbid_id(id_protocollo, "ID_protocollo")
    _forbid_id(id_lab, "ID_lab")
    _forbid_id(id_lotto, "ID_lotto")
    if len(rhex) != 64 or any(c not in "0123456789abcdef" for c in rhex):
        raise ValueError("Rhex deve essere 64 caratteri hex minuscoli")
    return f"{rhex}|{id_protocollo}|{id_lab}|{id_lotto}|{j}"


def digest_bytes(rhex: str, id_protocollo: str, id_lab: str, id_lotto: str, j: int) -> bytes:
    msg = message(rhex, id_protocollo, id_lab, id_lotto, j).encode("utf-8")
    return hashlib.sha256(msg).digest()


def pair_from_digest(h: bytes) -> Tuple[int, int]:
    u = h[0] >> 3
    s = (h[0] >> 2) & 1
    I = 1 + u
    D = +1 if s == 0 else -1
    return I, D


def derive_pair(rhex: str, id_protocollo: str, id_lab: str, id_lotto: str, j: int) -> Tuple[str, int, int]:
    h = digest_bytes(rhex, id_protocollo, id_lab, id_lotto, j)
    I, D = pair_from_digest(h)
    return h.hex(), I, D


def derive_all(
    rhex: str,
    id_protocollo: str,
    id_lab: str,
    id_lotto: str,
    n: int,
) -> Tuple[List[int], List[int], List[str]]:
    I: List[int] = []
    D: List[int] = []
    H: List[str] = []
    for j in range(1, n + 1):
        hx, i, d = derive_pair(rhex, id_protocollo, id_lab, id_lotto, j)
        H.append(hx)
        I.append(i)
        D.append(d)
    return I, D, H


def rstar_bytes(qbytes: bytes, m: int) -> bytes:
    import hmac as _hmac

    if len(qbytes) != 32:
        raise ValueError("Qbytes deve essere 32 byte")
    if m < 1:
        raise ValueError("m deve essere >= 1")
    msg = DOMAIN_MC + SEP + int(m).to_bytes(8, "big")
    return _hmac.new(qbytes, msg, hashlib.sha256).digest()


def rstar_hex(qbytes: bytes, m: int) -> str:
    return rstar_bytes(qbytes, m).hex()


def lowercase_hex(b: bytes) -> str:
    return b.hex()
