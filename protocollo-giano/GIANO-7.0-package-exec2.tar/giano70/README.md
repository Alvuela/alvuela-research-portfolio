# GIANO-7.0 — pacchetto minimo eseguibile

Non è un lotto confermativo. È il codice e il dataset dimostrativo che una pre-registrazione deve depositare insieme al testo normativo.

## File

| File | Ruolo |
|---|---|
| `derive.py` | `msg_j`, SHA-256, `(I_j, D_j)`, HMAC `R*` |
| `score.py` | `Tobs`, ciclo Monte Carlo, `p_MC = (c+1)/(M+1)` |
| `verify.py` | Appendice A + demo |
| `demo/` | `S.csv` (8×32), `V.txt`, `meta.json`, `expected.json` |
| `requirements.lock` | numpy |

## Esecuzione

```
cd giano70
python3 verify.py
```

Esito atteso: `PASS appendix A`, `PASS demo`, hash SHA-256 dei tre `.py`, `PASS GIANO-7.0 package`.

## Indici

Nel protocollo `I_j` è 1-based. In `score.py` l’accesso è `S[j-1, I-1]`.

## Demo

`N=8`, `M=1000`. Serve solo a congelare un `p_MC` riproducibile. Un lotto confermativo usa `N=4000` e `M=1000000` su dati sigillati, non questa matrice.
