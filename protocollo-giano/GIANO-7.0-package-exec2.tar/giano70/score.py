#!/usr/bin/env python3
"""GIANO-7.0 — T_obs e p_MC.

S è una matrice n x 32, righe j=1..n, colonne i=1..32 (1-based nel protocollo).
V è un insieme di indici j 1-based validi.
"""
from __future__ import annotations

import hashlib
import hmac
from typing import List, Sequence, Tuple

import numpy as np

from derive import DOMAIN_MC, SEP, derive_all, rstar_hex


def tobs(S: np.ndarray, V: Sequence[int], I: Sequence[int], D: Sequence[int]) -> float:
    if S.ndim != 2 or S.shape[1] != 32:
        raise ValueError("S deve avere 32 colonne")
    acc = 0.0
    for j in V:
        if j < 1 or j > S.shape[0]:
            raise ValueError(f"j fuori range: {j}")
        i = I[j - 1]
        if i < 1 or i > 32:
            raise ValueError(f"I_j fuori range: {i}")
        acc += D[j - 1] * float(S[j - 1, i - 1])
    return acc


def score_observed(
    S: np.ndarray,
    V: Sequence[int],
    rhex: str,
    id_protocollo: str,
    id_lab: str,
    id_lotto: str,
) -> Tuple[float, List[int], List[int]]:
    n = S.shape[0]
    I, D, _ = derive_all(rhex, id_protocollo, id_lab, id_lotto, n)
    return tobs(S, V, I, D), I, D


def p_mc(
    S: np.ndarray,
    V: Sequence[int],
    rhex: str,
    qbytes: bytes,
    id_protocollo: str,
    id_lab: str,
    id_lotto: str,
    M: int,
    first_k: int = 10,
) -> dict:
    T, I, D = score_observed(S, V, rhex, id_protocollo, id_lab, id_lotto, )
    n = S.shape[0]
    abs_obs = abs(T)
    c = 0
    first = []
    for m in range(1, M + 1):
        rh = rstar_hex(qbytes, m)
        if m <= first_k:
            first.append(rh)
        Im, Dm, _ = derive_all(rh, id_protocollo, id_lab, id_lotto, n)
        Tm = tobs(S, V, Im, Dm)
        if abs(Tm) >= abs_obs:
            c += 1
    p = (c + 1) / (M + 1)
    return {
        "Tobs": T,
        "c": c,
        "pMC": p,
        "M": M,
        "I": I,
        "D": D,
        "Rstar_first": first,
    }


def p_mc_fast(
    S: np.ndarray,
    V: Sequence[int],
    rhex: str,
    qbytes: bytes,
    id_protocollo: str,
    id_lab: str,
    id_lotto: str,
    M: int,
    first_k: int = 10,
) -> dict:
    """Stesso risultato di p_mc: stessi hash, stessi bit, stessa somma.

    Evita derive_all/tobs per ogni m. I vettori dell'Appendice A restano
    quelli di derive.py; questa routine non cambia la specifica.
    """
    T, I, D = score_observed(S, V, rhex, id_protocollo, id_lab, id_lotto)
    n = int(S.shape[0])
    S = np.ascontiguousarray(S, dtype=np.float64)
    v = [int(j) - 1 for j in V]
    mid = f"|{id_protocollo}|{id_lab}|{id_lotto}|".encode("utf-8")
    j_suf = [str(j).encode("ascii") for j in range(1, n + 1)]
    abs_obs = abs(T)
    c = 0
    first: List[str] = []
    for m in range(1, M + 1):
        rb = hmac.new(qbytes, DOMAIN_MC + SEP + m.to_bytes(8, "big"), hashlib.sha256).digest()
        rh = rb.hex()
        if m <= first_k:
            first.append(rh)
        rb_ascii = rh.encode("ascii")
        acc = 0.0
        for j0 in v:
            h0 = hashlib.sha256(rb_ascii + mid + j_suf[j0]).digest()[0]
            i = h0 >> 3
            d = +1.0 if ((h0 >> 2) & 1) == 0 else -1.0
            acc += d * S[j0, i]
        if abs(acc) >= abs_obs:
            c += 1
    p = (c + 1) / (M + 1)
    return {
        "Tobs": T,
        "c": c,
        "pMC": p,
        "M": M,
        "I": I,
        "D": D,
        "Rstar_first": first,
    }
