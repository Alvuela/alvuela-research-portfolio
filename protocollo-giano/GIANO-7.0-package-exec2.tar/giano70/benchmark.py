#!/usr/bin/env python3
"""Stima tempi di p_mc_fast. Non è un test confermativo."""
from __future__ import annotations

import time

import numpy as np

from score import p_mc_fast


def main() -> None:
    rng = np.random.default_rng(0)
    n, M = 4000, 20
    S = rng.normal(size=(n, 32))
    V = list(range(1, n + 1))
    rhex = "aa" * 32
    qbytes = bytes.fromhex("bb" * 32)
    t0 = time.perf_counter()
    out = p_mc_fast(S, V, rhex, qbytes, "GIANO-7.0", "BENCH-LAB", "BENCH-001", M, first_k=2)
    dt = time.perf_counter() - t0
    per = dt / M
    print(f"N={n} M={M} dt={dt:.3f}s  per_m={per:.3f}s")
    print(f"stima M=1e6: {per * 1_000_000 / 3600:.1f} h  (un processo)")
    print(f"Tobs={out['Tobs']:.6f} c={out['c']}")


if __name__ == "__main__":
    main()
