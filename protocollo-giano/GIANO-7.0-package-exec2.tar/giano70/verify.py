#!/usr/bin/env python3
"""GIANO-7.0 — verifica vettori d'appendice e dataset dimostrativo."""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import numpy as np

from derive import derive_pair, rstar_hex
from score import p_mc, p_mc_fast

ROOT = Path(__file__).resolve().parent
DEMO = ROOT / "demo"

APPENDIX_A1 = {
    1: ("f2654c98ab5f55c6b888a39205a88720dd8bcbdf81e3cd94949632c1507c9578", 31, 1),
    2: ("7177ccef01adb1a337db161b3fd0568e9b4dbfc86f75e02ae0bbd7066f020ebf", 15, 1),
    4000: ("fd8c7078402049450c629f560c5eb1d2970cf2d87053b1f650efe3cae2e854a7", 32, -1),
}
APPENDIX_A2 = {
    1: "71ed69c647c1b7a0a452f4cd2398cc39cc498e459e79e1bf236b5cbb7524a701",
    2: "d8061fe8ee662791b3b92d64126e689d7489903bc07f5f6695becb56da04c781",
    1000000: "7bb4f1577f0a02bde462b709d6a0ee9a5bb90d1919b378fdd49e05e3f84154aa",
}


def file_sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def check_appendix() -> None:
    rhex = "0" * 64
    proto, lab, lot = "GIANO-7.0", "TEST-LAB", "TEST-LOT-001"
    for j, exp in APPENDIX_A1.items():
        got = derive_pair(rhex, proto, lab, lot, j)
        if got != exp:
            raise SystemExit(f"FAIL A.1 j={j} got={got} exp={exp}")
    q = bytes([0x11] * 32)
    for m, exp in APPENDIX_A2.items():
        got = rstar_hex(q, m)
        if got != exp:
            raise SystemExit(f"FAIL A.2 m={m} got={got} exp={exp}")
    print("PASS appendix A")


def check_demo() -> None:
    meta = json.loads((DEMO / "meta.json").read_text(encoding="utf-8"))
    S = np.loadtxt(DEMO / "S.csv", delimiter=",", dtype=np.float64)
    V = [int(x) for x in (DEMO / "V.txt").read_text().split() if x]
    qbytes = bytes.fromhex(meta["Qhex"])
    out = p_mc(
        S,
        V,
        meta["Rhex"],
        qbytes,
        meta["ID_protocollo"],
        meta["ID_lab"],
        meta["ID_lotto"],
        meta["M"],
        first_k=10,
    )
    exp = json.loads((DEMO / "expected.json").read_text(encoding="utf-8"))
    if abs(out["Tobs"] - exp["Tobs"]) > 1e-12:
        raise SystemExit(f"FAIL Tobs {out['Tobs']} != {exp['Tobs']}")
    if out["c"] != exp["c"]:
        raise SystemExit(f"FAIL c {out['c']} != {exp['c']}")
    if abs(out["pMC"] - exp["pMC"]) > 1e-15:
        raise SystemExit(f"FAIL pMC {out['pMC']} != {exp['pMC']}")
    if out["Rstar_first"] != exp["Rstar_first"]:
        raise SystemExit("FAIL Rstar_first")
    fast = p_mc_fast(
        S,
        V,
        meta["Rhex"],
        qbytes,
        meta["ID_protocollo"],
        meta["ID_lab"],
        meta["ID_lotto"],
        meta["M"],
        first_k=10,
    )
    if fast["c"] != out["c"] or fast["Rstar_first"] != out["Rstar_first"] or abs(fast["Tobs"] - out["Tobs"]) > 1e-15:
        raise SystemExit(f"FAIL fast!=ref c={fast['c']} {out['c']}")
    print(
        "PASS demo",
        f"Tobs={out['Tobs']:.17g}",
        f"c={out['c']}",
        f"pMC={out['pMC']:.17g}",
        "fast=ref",
    )


def hashes() -> None:
    for name in ("derive.py", "score.py", "verify.py"):
        print(f"SHA256 {name} {file_sha256(ROOT / name)}")


def main() -> int:
    check_appendix()
    check_demo()
    hashes()
    print("PASS GIANO-7.0 package")
    return 0


if __name__ == "__main__":
    sys.exit(main())
